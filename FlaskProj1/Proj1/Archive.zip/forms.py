from typing import Dict

from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField, SubmitField
from wtforms.validators import Length, DataRequired
from wtforms.widgets.html5 import NumberInput
from wtforms.fields.html5 import TelField


class PhoneRecharge(FlaskForm):
    prvlst: Dict[str, str] = {'Airtel': 'AT',
                              'BSNL': 'BS',
                              'Idea': 'ID',
                              'Vodafone': 'VF',
                              'Tata Docomo GSM': 'TD',
                              'Tata Docomo CDMA': 'TA',
                              'Jio': 'JP'}
    phoneno = TelField('Phone Number', widget=NumberInput(), validators=[DataRequired()])
    prvdr = SelectField('Select Operator',
                        choices=[('AT', 'Airtel'), ('BS', 'BSNL'), ('ID', 'Idea'), ('VF', 'Vodafone'),
                                 ('TD', 'Tata Docomo GSM'), ('TA', 'Tata Docomo CDMA'), ('JP', 'Jio')],
                        validators=[DataRequired()])
    amtrec = StringField('Amount', widget=NumberInput(), validators=[DataRequired()])
    rechg = SubmitField('Recharge')


class MetroRecharge(FlaskForm):
    phoneno = TelField('Phone Number', widget=NumberInput(), validators=[DataRequired()])
    prvdr = SelectField('Select Operator',
                        choices=[('AT', 'Airtel'), ('BS', 'BSNL'), ('ID', 'Idea'), ('VF', 'Vodafone'),
                                 ('TD', 'Tata Docomo GSM'), ('TA', 'Tata Docomo CDMA'), ('JP', 'Jio')],
                        validators=[DataRequired()])
    amtrec = StringField('Amount', widget=NumberInput(), validators=[DataRequired()])
    rechg = SubmitField('Recharge')


class DTHRecharge(FlaskForm):
    phoneno = TelField('Phone Number', widget=NumberInput(), validators=[DataRequired()])
    prvdr = SelectField('Select Operator',
                        choices=[('AT', 'Airtel'), ('BS', 'BSNL'), ('ID', 'Idea'), ('VF', 'Vodafone'),
                                 ('TD', 'Tata Docomo GSM'), ('TA', 'Tata Docomo CDMA'), ('JP', 'Jio')],
                        validators=[DataRequired()])
    amtrec = StringField('Amount', widget=NumberInput(), validators=[DataRequired()])
    rechg = SubmitField('Recharge')


class WaterRecharge(FlaskForm):
    phoneno = TelField('Phone Number', widget=NumberInput(), validators=[DataRequired()])
    prvdr = SelectField('Select Operator',
                        choices=[('AT', 'Airtel'), ('BS', 'BSNL'), ('ID', 'Idea'), ('VF', 'Vodafone'),
                                 ('TD', 'Tata Docomo GSM'), ('TA', 'Tata Docomo CDMA'), ('JP', 'Jio')],
                        validators=[DataRequired()])
    amtrec = StringField('Amount', widget=NumberInput(), validators=[DataRequired()])
    rechg = SubmitField('Recharge')


class ElectRecharge(FlaskForm):
    phoneno = TelField('Phone Number', widget=NumberInput(), validators=[DataRequired()])
    prvdr = SelectField('Select Operator',
                        choices=[('AT', 'Airtel'), ('BS', 'BSNL'), ('ID', 'Idea'), ('VF', 'Vodafone'),
                                 ('TD', 'Tata Docomo GSM'), ('TA', 'Tata Docomo CDMA'), ('JP', 'Jio')],
                        validators=[DataRequired()])
    amtrec = StringField('Amount', widget=NumberInput(), validators=[DataRequired()])
    rechg = SubmitField('Recharge')