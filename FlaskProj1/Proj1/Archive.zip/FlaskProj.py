from flask import Flask, render_template, flash, redirect, url_for
from forms import PhoneRecharge
import requests

app = Flask(__name__)

app.config['SECRET_KEY'] = "abc123hij456lmn789"


@app.route("/")
@app.route("/main")
def hello():
    return render_template('HomePage.html', title='Main')


@app.route("/about")
def about():
    return render_template('PhoneRech.html', title='Phone Recharge')


@app.route("/Phone", methods={'GET', 'POST'})
def phrech():
    form = PhoneRecharge()
    if form.validate_on_submit():
        resp = rech(provider_id={form.prvdr.data}, number=form.phoneno.data, amount=form.amtrec.data)
        flash(resp, "success")
        # return redirect(url_for("hello"))
    return render_template('PhoneRech.html', title='Phone Recharge', form=form)


def rech(provider_id, number, amount):
    usr_id = '10328'
    api_token = '635318977caf669aa2caba6829b0da3d'
    client_id = 'MM18012020'
    URL= 'https://ambikaecom.net/API/TransactionAPI?'
    PARAMS= {'UserID':usr_id,
             'Token': api_token,
             'SPKey': provider_id,
             'Account': number,
             'Amount': amount,
             'APIRequestID': client_id,
             'OutletID': usr_id,
             'Format': 1}
    #response = requests.get(f'https://ambikaecom.net/API/TransactionAPI?UserID={usr_id}&Token={api_token}&SPKey={provider_id}&Account={number}&Amount={amount}&APIRequestID={client_id}&OutletID={usr_id}&Format=1')
    response = requests.get(url=URL, params=PARAMS)
    #data= response.json()
    print(response)
    return response.url


@app.route("/Metro", methods={'GET', 'POST'})
def mtrech():
    form = PhoneRecharge()
    if form.validate_on_submit():
        resp = rech(provider_id={form.prvdr.data}, number=form.phoneno.data, amount=form.amtrec.data)
        flash(resp, "success")
        # return redirect(url_for("hello"))
    return render_template('MetroRech.html', title='Phone Recharge', form=form)


@app.route("/Elect", methods={'GET', 'POST'})
def elrech():
    form = PhoneRecharge()
    if form.validate_on_submit():
        resp = rech(provider_id={form.prvdr.data}, number=form.phoneno.data, amount=form.amtrec.data)
        flash(resp, "success")
        # return redirect(url_for("hello"))
    return render_template('ElectRech.html', title='Phone Recharge', form=form)


@app.route("/Water", methods={'GET', 'POST'})
def wtrech():
    form = PhoneRecharge()
    if form.validate_on_submit():
        resp = rech(provider_id={form.prvdr.data}, number=form.phoneno.data, amount=form.amtrec.data)
        flash(resp, "success")
        # return redirect(url_for("hello"))
    return render_template('WaterRech.html', title='Phone Recharge', form=form)


@app.route("/DTH", methods={'GET', 'POST'})
def dthrech():
    form = PhoneRecharge()
    if form.validate_on_submit():
        resp = rech(provider_id={form.prvdr.data}, number=form.phoneno.data, amount=form.amtrec.data)
        flash(resp, "success")
        # return redirect(url_for("hello"))
    return render_template('DTHRech.html', title='Phone Recharge', form=form)



if __name__ == '__main__':
    app.run(debug=True)
